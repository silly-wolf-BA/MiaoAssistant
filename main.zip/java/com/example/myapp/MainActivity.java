package com.example.myapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private TextView statusTextView;
    private Button enableButton;
    private CheckBox addMiaoCheckBox;
    private CheckBox replaceWoCheckBox;
    private EditText demoInputEditText;
    private Button demoButton;
    private TextView demoResultTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusTextView = (TextView) findViewById(R.id.statusTextView);
        enableButton = (Button) findViewById(R.id.enableButton);
        addMiaoCheckBox = (CheckBox) findViewById(R.id.addMiaoCheckBox);
        replaceWoCheckBox = (CheckBox) findViewById(R.id.replaceWoCheckBox);
        demoInputEditText = (EditText) findViewById(R.id.demoInputEditText);
        demoButton = (Button) findViewById(R.id.demoButton);
        demoResultTextView = (TextView) findViewById(R.id.demoResultTextView);

        enableButton.setBackgroundColor(0xFFFF9800);
        demoButton.setBackgroundColor(0xFFFF9800);

        enableButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                Toast.makeText(MainActivity.this, "请在无障碍列表开启", Toast.LENGTH_SHORT).show();
            }
        });

        demoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String input = demoInputEditText.getText().toString();
                if (input.trim().length() == 0) {
                    Toast.makeText(MainActivity.this, "请输入文字", Toast.LENGTH_SHORT).show();
                    return;
                }
                boolean addMiao = addMiaoCheckBox.isChecked();
                boolean replaceWo = replaceWoCheckBox.isChecked();
                String result = transformText(input, addMiao, replaceWo);
                demoResultTextView.setText(result);
            }
        });

        checkServiceStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkServiceStatus();
    }

    private void checkServiceStatus() {
        boolean enabled = isServiceEnabled();
        if (enabled) {
            statusTextView.setText("✅ 已开启");
            statusTextView.setTextColor(0xFF00CC00);
            enableButton.setText("已开启");
        } else {
            statusTextView.setText("❌ 未开启");
            statusTextView.setTextColor(0xFFFF0000);
            enableButton.setText("去设置开启");
        }
    }

    private boolean isServiceEnabled() {
        String service = getPackageName() + "/" + MiaoAccessibilityService.class.getCanonicalName();
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return enabled != null && enabled.contains(service);
    }

    private String transformText(String text, boolean addMiao, boolean replaceWo) {
        String result = text;
        if (replaceWo) {
            result = result.replace("我", "本咪");
        }
        if (addMiao) {
            char[] puncs = {'。', '！', '？', '；'};
            int idx = -1;
            for (int i = result.length() - 1; i >= 0; i--) {
                char c = result.charAt(i);
                for (char p : puncs) {
                    if (c == p) {
                        idx = i;
                        break;
                    }
                }
                if (idx != -1) break;
            }
            if (idx != -1) {
                result = result.substring(0, idx) + "喵" + result.substring(idx);
            } else {
                result = result + "喵";
            }
        }
        return result;
    }
}