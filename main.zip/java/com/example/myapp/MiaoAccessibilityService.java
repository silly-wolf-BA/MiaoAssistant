package com.example.myapp;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.os.Bundle;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

public class MiaoAccessibilityService extends AccessibilityService {

    private String lastText = "";

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
        info.eventTypes = AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS;
        info.notificationTimeout = 100;
        setServiceInfo(info);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        AccessibilityNodeInfo source = event.getSource();
        if (source == null || !source.isEditable()) return;

        // 如果你想只对 QQ 生效，取消下面这两行的注释（删掉 // 即可）：
        // String pkg = event.getPackageName().toString();
        // if (!pkg.equals("com.tencent.mobileqq")) return;

        String currentText = source.getText() != null ? source.getText().toString() : "";
        if (currentText.isEmpty()) {
            lastText = "";
            return;
        }

        // 判断是否刚输入了句号、问号等标点
        boolean isPuncAdded = currentText.length() == lastText.length() + 1 &&
                isPunctuation(currentText.charAt(currentText.length() - 1));

        if (!isPuncAdded) {
            lastText = currentText;
            return;
        }

        // 执行转换：替换“我” + 加“喵”
        String newText = currentText.replace("我", "本咪");
        char[] puncs = {'。', '！', '？', '；'};
        int idx = -1;
        for (int i = newText.length() - 1; i >= 0; i--) {
            char c = newText.charAt(i);
            for (char p : puncs) {
                if (c == p) {
                    idx = i;
                    break;
                }
            }
            if (idx != -1) break;
        }
        if (idx != -1) {
            newText = newText.substring(0, idx) + "喵" + newText.substring(idx);
        } else {
            newText = newText + "喵";
        }

        // 将转换后的文字设置回输入框
        if (!newText.equals(currentText)) {
            Bundle args = new Bundle();
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, newText);
            source.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
            lastText = newText;
        } else {
            lastText = currentText;
        }
    }

    private boolean isPunctuation(char c) {
        return c == '。' || c == '！' || c == '？' || c == '；';
    }

    @Override
    public void onInterrupt() {
        lastText = "";
    }
}